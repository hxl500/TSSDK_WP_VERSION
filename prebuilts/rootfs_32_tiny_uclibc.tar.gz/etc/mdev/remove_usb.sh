#!/bin/sh

# sd*
sdname=$1

function _echo()
{
        echo $1 > /dev/console
}

function get_mnt_point()
{
        case $1 in
                "sda")
                        mountpoint="usb0"
                        ;;

		"sda1")
                        mountpoint="usb0"
                        ;;

                "sda2")
                        mountpoint="usb1"
                        ;;

                "sda3")
                        mountpoint="usb2"
                        ;;

                "sda4")
                        mountpoint="usb3"
                        ;;
                *)
                        _echo "mountpoint not defined for $1"
                        exit 1
        esac
}

# parse sda, sda1, sda2, ... , sdb ...
_echo "delete usb dev $sdname"
get_mnt_point $sdname
umount /media/$mountpoint
if [ $? == 0 ] ; then
        _echo "umount /media/$mountpoint success"
else
        _echo "umount /media/$mountpoint fail"
fi


