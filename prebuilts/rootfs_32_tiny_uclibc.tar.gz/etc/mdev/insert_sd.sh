#!/bin/sh

# mmcblk*
mmcname=$1

function _echo()
{
	echo $1 > /dev/console
}

# check emmc and sdcard type by /dev/mmcblk*boot*
if [ ! -e /dev/${mmcname}boot0 ] ; then
	for dev in /dev/${mmcname}p* ; do
		if [ -e "$dev" ] ; then
			_echo "detect new sdcard dev $dev"
			mount $dev /media/${dev#/dev/}
			if [ $? == 0 ] ; then
				_echo "mount $dev /media/${dev#/dev/} success"
			else
				_echo "mount $dev /media/${dev#/dev/} fail"
			fi
		fi
	done
fi



