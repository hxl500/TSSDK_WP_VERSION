#!/bin/sh

# sd*
sdname=$1

function _echo()
{
	echo $1 > /dev/console
}

function get_mnt_point()
{
	case $1 in
		"sda1")
        	   	mountpoint="usb0"
           		;;

		"sda2")
           		mountpoint="usb1"
           		;;

	        "sda3")
        	   	mountpoint="usb2"
           		;;

       		"sda4")
       			mountpoint="usb3"
           		;;

		*)
			_echo "mountpoint not defined for $1"
			exit 1
	esac
}

# parse sda, sda1, sda2, ... , sdb ...
if [ -e "$sdname" ] ; then
	get_mnt_point $sdname
	_echo "detect new usb dev $sdname, mp $mountpoint"
	mkdir -p /media/$mountpoint
	mount /dev/$sdname /media/$mountpoint
	if [ $? == 0 ] ; then
		_echo "mount $sdname /media/$mountpoint success"
	else
		_echo "mount $sdname /media/$mountpoint fail"
	fi
fi


