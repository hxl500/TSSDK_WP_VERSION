#!/bin/sh

# mmcblk*p*
mmcname=$1

function _echo()
{
	echo $1 > /dev/console
}

# check emmc and sdcard type by /dev/mmcblk*boot*
umount /media/${mmcname}
if [ $? == 0 ] ; then
	_echo "umount /media/${mmcname} success"
else
	_echo "umount /media/${mmcname} fail"
fi

